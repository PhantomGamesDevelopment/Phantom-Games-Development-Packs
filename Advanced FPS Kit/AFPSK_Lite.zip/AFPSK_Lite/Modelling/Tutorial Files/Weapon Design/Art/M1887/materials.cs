
singleton Material(Model1887_Mat)
{
   mapTo = "Model1887_Mat";
   diffuseColor[0] = "0.64 0.64 0.64 1";
   specular[0] = "0.5 0.5 0.5 1";
   specularPower[0] = "50";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "art/shapes/weapons/M1887/M1887_D.png";
   normalMap[0] = "art/shapes/weapons/M1887/M1887_N.png";
   specularMap[0] = "art/shapes/weapons/M1887/M1887_S.png";
};
