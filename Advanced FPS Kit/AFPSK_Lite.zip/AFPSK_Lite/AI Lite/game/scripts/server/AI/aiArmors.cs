//aiArmors.cs
//Robert Fritzen (Phantom139)
//(C) 2014, Phantom Games Development
//Armor Datablocks and definitions for AI

datablock PlayerData(GenericAI : DefaultPlayerData) {
   shootingDelay = 200;
};
